Striped 2.5 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

And here's a new one: Striped, which features a clean, minimalistic design, styling for 
all basic page elements (including blockquotes, tables and lists), a repositionable 
sidebar (left or right), and HTML5/CSS3 code designed for quick and easy customization 
(see code comments for details).

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33

Credits:

	Images:
		AJ (n33.co) -- n33-robot-invader.jpg (for demo purposes only!)
		fotogrph (fotogrph.com)

	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		skelJS (skeljs.org)