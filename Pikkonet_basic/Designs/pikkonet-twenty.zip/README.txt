Twenty 1.0 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Twenty, a minimal, multi-page responsive site template for HTML5 UP.

As the name implies, this is my twentieth (!) design for HTML5 UP. Since the last
few have been single page affairs, I decided to go with something a bit more conventional
and threw in four extra page layouts. Beyond that, it's the usual drill: fully responsive,
built on HTML5/CSS3/skel, and CCA licensed like all my other stuff.

Special thanks to Michael Domaradzki (mdomaradzki.deviantart.com) for allowing me to
use his excellent photos in Twenty's demo*.

(* Not included with this download (replaced with generic placeholder images), as
I only have permission to use his work in my own on-site demos. Do NOT download
or use any of his work without prior explicit permission.)


AJ
n33.co @n33co dribbble.com/n33



Credits
=======

	Images (Demo Only)
		Michael Domaradzki (http://mdomaradzki.deviantart.com/)	
			"Night Vision" (http://mdomaradzki.deviantart.com/art/Night-Vision-384070222)
			"At the Station II" (http://mdomaradzki.deviantart.com/art/At-the-Station-II-37023322)
			"Airchitecture II" (http://mdomaradzki.deviantart.com/art/Airchitecture-II-385212804)
			"Livewires II" (http://mdomaradzki.deviantart.com/art/Livewires-II-358817199)
			"Midnite Xpress I" (http://mdomaradzki.deviantart.com/art/Midnite-Xpress-I-371126495)

	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)

	Other
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		background-size polyfill (https://github.com/louisremi/background-size-polyfill)
		Misc jQuery plugins (n33.co)
		skel (n33.co)